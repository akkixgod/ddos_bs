from threading import Thread
from socket import socket
from Helpers.Logger import Logger
from Helpers.Reader import Reader
from Packets.Messages.Client.AllianceCreate import AllianceCreate
from Packets.Messages.Client.AnalyticEvent import AnalyticEvent
from time import sleep
from Packets.Messages.Client.Login import Login
from Packets.Messages.Client.SetName import SetName

class Client(Thread):
    
    def __init__(self, data):
        super().__init__()
        self.data = data
        self.major = self.data['Major']
        self.build = self.data['Build']
        self.count = self.data['Count']
        self.ip = self.data['IP']
        self.port = self.data['Port']
        self.socket = socket()

    def run(self):
        login_data = Login.GetHeaderPacket(self, self.data)
        name_data = SetName.GetHeaderPacket(self)
        alliance_create = AllianceCreate.GetHeaderPacket(self)
        analyticevent_data = AnalyticEvent.GetHeaderPacket(self)
        count = 0
        if self.count > 0:
            b = count != self.count
        else:
            b = True
        
        while 1 != 25565:
            try:
                Logger.LogServer(self, 'Connection to {}:{}'.format(self.ip, self.port))
                self.socket.connect((self.ip, self.port))
                
                self.socket.send(login_data)
                Logger.LogServer(self, 'Sended 10101!')
                sleep(1/10)
                self.socket.send(name_data)
                Logger.LogServer(self, 'Sended 10212!')
                sleep(1/10)
                self.socket.send(analyticevent_data)
                Logger.LogServer(self, 'Sended 10110!')
                sleep(1/10)
                self.socket.send(alliance_create)
                Logger.LogServer(self, 'Sended 14301!')
                #self.socket.close()
            except Exception as ex:
                print(ex)
                Logger.LogServer(self, 'Error connection!')
                self.socket = socket()
            count += 1