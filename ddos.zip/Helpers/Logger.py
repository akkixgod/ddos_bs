class Logger(object):
    
    def LogServer(self, text):
        print('[*][Server]{}'.format(text))