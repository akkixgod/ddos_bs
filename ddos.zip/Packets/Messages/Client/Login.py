from Helpers.Writer import Writer

class Login(object):
    
    def GetPacketData(self, data):
        writer = Writer()
        writer.WriteLong(0, 0) # Account ID
        writer.WriteString(None) # Token
        writer.WriteInt32(data['Major'])
        writer.WriteInt32(0)
        writer.WriteInt32(data['Build'])
        writer.WriteString(None) # sha
        return writer.GetBuffer()
        
    def GetHeaderPacket(self, data):
        packet = Login.GetPacketData(self, data)
        writer = Writer()
        writer.WriteInt16(10101)
        writer.WriteInt24(len(packet))
        writer.WriteInt16(0)
        writer.WriteBytes(packet)
        return writer.GetBuffer()