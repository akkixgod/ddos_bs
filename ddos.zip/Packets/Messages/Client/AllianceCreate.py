from Helpers.Writer import Writer
from random import randint, choice

class AllianceCreate(object): 
    
    def GetPacketData(self):
        writer = Writer()
        writer.WriteString('{}{}'.format('Club', randint(0, 2147483647))) # Name
        writer.WriteString('') # Description
        writer.WriteDataReference(8, 0) # Badge ID
        writer.WriteDataReference(14, 0) # Region ID
        writer.WriteVInt(1) # Type
        writer.WriteVInt(25565) # Required Trophies
        writer.WriteBoolean(True) # Family
        return writer.GetBuffer()
        
    def GetHeaderPacket(self):
        packet = AllianceCreate.GetPacketData(self)
        writer = Writer()
        writer.WriteInt16(14301)
        writer.WriteInt24(len(packet))
        writer.WriteInt16(0)
        writer.WriteBytes(packet)
        return writer.GetBuffer()