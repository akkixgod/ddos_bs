﻿from Helpers.Writer import Writer
from random import randint, choice

class AnalyticEvent(object):
    
    def GetPacketData(self):
        writer = Writer()
        writer.WriteString('Luna Negr')
        writer.WriteString('With love\nKasper❤')
        return writer.GetBuffer()
        
    def GetHeaderPacket(self):
        packet = AnalyticEvent.GetPacketData(self)
        writer = Writer()
        writer.WriteInt16(10110)
        writer.WriteInt24(len(packet))
        writer.WriteInt16(0)
        writer.WriteBytes(packet)
        return writer.GetBuffer()