from Helpers.Writer import Writer
from random import randint, choice

class SetName(object):
    
    def GetPacketData(self):
        writer = Writer()
        writer.WriteString('{}{}'.format(choice(['Bot', 'Player', 'Negr']), randint(0, 2147483647))) # Name
        writer.WriteBoolean(True) # State
        return writer.GetBuffer()
        
    def GetHeaderPacket(self):
        packet = SetName.GetPacketData(self)
        writer = Writer()
        writer.WriteInt16(10212)
        writer.WriteInt24(len(packet))
        writer.WriteInt16(0)
        writer.WriteBytes(packet)
        return writer.GetBuffer()