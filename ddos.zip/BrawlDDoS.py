from Core.Server import Server

ip = input('Enter IP >> ')
port = input('Enter Port >> ')
version = input('Enter Version (Major, Build (Example: 26.165)) >> ')
thread_count = input('Enter Thread Count >> ')
count = input('Enter Count (0 - Unlimited) >> ')

port = int(port)
major = int(version.split('.')[0])
thread_count = int(thread_count)
build = int(version.split('.')[1])
count = int(count)

Server({'IP': ip, 'Port': port, 'Major': major, 'Build': build, 'ThreadCount': thread_count, 'Count': count}).Start()